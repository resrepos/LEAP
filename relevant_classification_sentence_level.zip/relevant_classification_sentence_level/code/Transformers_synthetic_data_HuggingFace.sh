#!/bin/bash --login
#$ -cwd
#$ -N synthetic_data_haggingface
#$ -m bea
#$ -l nvidia_v100=4
#$ -pe smp.pe 32

module purge
module load apps/binapps/anaconda3/2021.11
module load tools/env/proxy2
module load libs/cuda
#module load apps/python/scikitlearn/0.21.3
#module load apps/anaconda3/5.2.0/bin
module list

python3 --version
#python3 -m pip install --user transformers==4.20.0
#python3 -m pip install --user tensorflow==2.9.1
#python3 -m pip install --user datasets==2.2.2
#python3 -m pip install --user torch==1.11.0

#transformers --version
#tensorflow --version
#datasets --version
#torch --version
##$ -ac nvmps





#Declare a string array
ModelArray=("xlnet-base-cased"  "xlnet-large-cased"  "roberta-base"  "roberta-large"  "distilroberta-base"  "distilbert-base-uncased"  "distilbert-base-cased"  "bert-base-uncased"  "bert-base-cased"  "bert-large-uncased"  "bert-large-cased"  "bert-large-uncased-whole-word-masking"  "bert-large-cased-whole-word-masking"  "albert-base-v2"  "albert-large-v2")
 
# Print array values in  lines
export OMP_NUM_THREADS=$NSLOTS
seeds=(0 42)
mkdir synthetic_data_results
for s in ${seeds[@]};do
  mkdir synthetic_data_results/Seed${s}
  e=10
  mkdir synthetic_data_results/Seed${s}/Epoch${e}
  echo  synthetic_data_results/Seed${s}/Epoch${e} ${e} ${s}
  for model in ${ModelArray[*]}; do
    echo $model
    mkdir synthetic_data_results/Seed${s}/Epoch${e}/$model
    python3 -m torch.distributed.launch --nproc_per_node 4 ./code/run_glue.py --model_name_or_path $model --train_file './datasets/synthetic/training_data2.json' --validation_file './datasets/synthetic/validation_data2.json' --test_file './datasets/synthetic/testing_data2.json' --do_train --do_eval --do_predict --max_seq_length 128 --per_device_train_batch_size 8 --per_device_eval_batch_size 8 --learning_rate 5e-5 --num_train_epochs ${e} --output_dir ./synthetic_data_results/Seed${s}/Epoch${e}/$model --save_strategy "epoch" --load_best_model_at_end True --evaluation_strategy "epoch" --seed ${s}
    python3 ./code/predict.py --test_file ./datasets/synthetic/testing_data2.json --prediction_file ./synthetic_data_results/Seed${s}/Epoch${e}/$model/predict_results_None.txt --save_file ./synthetic_data_results/Seed${s}/Epoch${e}/$model/prediction_results_final.txt
  done
done
