import argparse
import sklearn
import pandas as pd
import json
from sklearn.metrics import classification_report

# Initialize parser
parser = argparse.ArgumentParser()
# Adding optional argument

parser.add_argument("--test_file", help = "path to test file in json formate.")
parser.add_argument("--prediction_file", help = "path to prediction results file in txt formate.")
parser.add_argument("--save_file", help = "path to save prediction results classification report file in txt formate.")

args = parser.parse_args()

#lines = []
#json_file = open(args.test_file, "r")
#json_file = json_file.read().split("\"}")

#for line in json_file:
    #if len(line)>0:
        #print(line + "\"}")
        #l = line + "\"}"
        #lines.append(json.loads(l))
df_true = pd.read_json(args.test_file, lines=True)

#df_true = pd.DataFrame(lines)

df_pred = pd.read_csv(args.prediction_file, sep="\t")

y_pred = df_pred['prediction'].tolist()
y_true = df_true['label'].tolist()

report = classification_report(y_true, y_pred)
print(report)

prediction_file = open(args.save_file, 'w')
prediction_file.write(report)
prediction_file.close()

